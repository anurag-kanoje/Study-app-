export default function StudyGroupsPage() {
  return (
    <div>
      <h1 className="text-3xl font-bold mb-4">Virtual Study Groups</h1>
      <p>Join or create virtual study groups. Coming soon!</p>
    </div>
  )
}

