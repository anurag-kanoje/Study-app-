export default function EssayAssistantPage() {
  return (
    <div>
      <h1 className="text-3xl font-bold mb-4">Essay Writing Assistant</h1>
      <p>Get help with your essays. This feature is under development.</p>
    </div>
  )
}

