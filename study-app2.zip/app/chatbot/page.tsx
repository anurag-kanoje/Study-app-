export default function ChatbotPage() {
  return (
    <div>
      <h1 className="text-3xl font-bold mb-4">AI Chatbot</h1>
      <p>Welcome to the AI Chatbot. This feature is coming soon!</p>
    </div>
  )
}

