export default function FlashcardsPage() {
  return (
    <div>
      <h1 className="text-3xl font-bold mb-4">AI Flashcards</h1>
      <p>Create and study with AI-powered flashcards. This feature is coming soon!</p>
    </div>
  )
}

