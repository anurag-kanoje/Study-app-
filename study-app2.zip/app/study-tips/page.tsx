export default function StudyTipsPage() {
  return (
    <div>
      <h1 className="text-3xl font-bold mb-4">Study Tips</h1>
      <p>Personalized study tips will be available here soon!</p>
    </div>
  )
}

