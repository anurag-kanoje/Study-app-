export default function TranslationPage() {
  return (
    <div>
      <h1 className="text-3xl font-bold mb-4">Language Translation</h1>
      <p>Translate your study materials. This feature is under development.</p>
    </div>
  )
}

