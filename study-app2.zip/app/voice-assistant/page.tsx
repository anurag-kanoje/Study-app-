export default function VoiceAssistantPage() {
  return (
    <div>
      <h1 className="text-3xl font-bold mb-4">Voice Assistant</h1>
      <p>Interact with your voice assistant. This feature is coming soon!</p>
    </div>
  )
}

