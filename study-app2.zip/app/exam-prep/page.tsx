export default function ExamPrepPage() {
  return (
    <div>
      <h1 className="text-3xl font-bold mb-4">Exam Preparation</h1>
      <p>Prepare for your exams effectively. Coming soon!</p>
    </div>
  )
}

