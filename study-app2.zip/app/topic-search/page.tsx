export default function TopicSearchPage() {
  return (
    <div>
      <h1 className="text-3xl font-bold mb-4">Topic Search</h1>
      <p>Search and summarize topics easily. This feature is coming soon!</p>
    </div>
  )
}

