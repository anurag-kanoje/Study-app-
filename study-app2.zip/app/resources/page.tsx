export default function ResourcesPage() {
  return (
    <div>
      <h1 className="text-3xl font-bold mb-4">Learning Resources</h1>
      <p>Access a wide range of learning resources. Coming soon!</p>
    </div>
  )
}

