export default function MentalHealthPage() {
  return (
    <div>
      <h1 className="text-3xl font-bold mb-4">Mental Health Support</h1>
      <p>Access mental health resources and support. This feature is under development.</p>
    </div>
  )
}

