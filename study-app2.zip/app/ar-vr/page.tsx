export default function ArVrPage() {
  return (
    <div>
      <h1 className="text-3xl font-bold mb-4">AR/VR Learning</h1>
      <p>Experience augmented and virtual reality learning. Coming soon!</p>
    </div>
  )
}

