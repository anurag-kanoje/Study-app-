export default function GlobalResourcesPage() {
  return (
    <div>
      <h1 className="text-3xl font-bold mb-4">Global Resources</h1>
      <p>Access learning resources from around the world. Coming soon!</p>
    </div>
  )
}

