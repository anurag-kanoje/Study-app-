export default function MultiSensoryPage() {
  return (
    <div>
      <h1 className="text-3xl font-bold mb-4">Multi-Sensory Tools</h1>
      <p>Explore multi-sensory learning tools. Coming soon!</p>
    </div>
  )
}

